import { useEffect, useState } from 'react'
import { backendReady, selectRows } from '../lib/api.js'

// Loads all rows of a Supabase table (public REST call, no SDK), ordered by one column. Without a configured backend it resolves to an empty list.
export function useRows(table, order) {
  const [s, setS] = useState({ rows: [], loading: true, error: false })
  useEffect(() => {
    if (!backendReady) { setS({ rows: [], loading: false, error: false }); return }
    let live = true
    selectRows(table, order)
      .then((data) => { if (live) setS({ rows: data || [], loading: false, error: false }) })
      .catch(() => { if (live) setS({ rows: [], loading: false, error: true }) })
    return () => { live = false }
  }, [table, order])
  return s
}
