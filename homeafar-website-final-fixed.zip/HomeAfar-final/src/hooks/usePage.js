import { useEffect } from 'react'
import { ROUTES, fullTitle, canonical } from '../data/seo.js'

const setAttr = (selector, attr, value) => document.querySelector(selector)?.setAttribute(attr, value)

// Applies a page's title, description, canonical URL and social tags, then scrolls to the top.
// `path` is a key of ROUTES (src/data/seo.js). Pages without an entry (404, admin) pass `title` and `noindex`.
export function usePage(path, { title, noindex = false } = {}) {
  useEffect(() => {
    const [short, description] = ROUTES[path] || [title, '']
    const t = fullTitle(short)
    document.title = t
    if (description) {
      setAttr('meta[name="description"]', 'content', description)
      setAttr('meta[property="og:description"]', 'content', description)
      setAttr('meta[name="twitter:description"]', 'content', description)
    }
    setAttr('meta[property="og:title"]', 'content', t)
    setAttr('meta[name="twitter:title"]', 'content', t)
    if (ROUTES[path]) {
      const url = canonical(path)
      setAttr('link[rel="canonical"]', 'href', url)
      setAttr('meta[property="og:url"]', 'content', url)
    }
    let robots = document.querySelector('meta[name="robots"]')
    if (noindex) {
      if (!robots) { robots = document.createElement('meta'); robots.name = 'robots'; document.head.appendChild(robots) }
      robots.content = 'noindex, nofollow'
    } else robots?.remove()
    window.scrollTo(0, 0)
  }, [path, title, noindex])
}
